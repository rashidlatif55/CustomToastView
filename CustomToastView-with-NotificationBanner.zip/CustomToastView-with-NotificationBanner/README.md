# CustomToastView

# Screenshot
<p align="center">
  <img src="https://github.com/rashidlatif55/CustomToastView/blob/main/Screen%20Shot%202022-07-22%20at%204.44.18%20PM.png" width="350" title="Example screenshot">
</p>

