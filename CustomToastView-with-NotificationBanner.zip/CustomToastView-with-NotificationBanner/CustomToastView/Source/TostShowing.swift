

import UIKit

public enum ToastType:CaseIterable {
    case success
    case error
    case warning
    case info
}

public enum ToastDuration {
    case short
    case medium
    case long
    case custom(Double)
}

protocol TostShowing{
    
    /// Present the Tost
    /// - Parameters:

    /// Present the Tost
    /// - Parameters:
    ///   - header: Title of tost
    ///   - message: Description of tost
    ///   - toastType: `ToastType` , success , error, warning, info
    ///   - duration: `ToastDuration` short, medium,  long and custom. Default will be medium
    ///   - toastGravity: `ToastGravity` top, center, bottom
    ///   - toastCornerRadius: default value is 10
    ///   - delegate:
    func showTost(header: String, message: String,toastType: ToastType, duration: ToastDuration?, toastGravity: BannerPosition?, toastCornerRadius: Int?,delegate:NotificationBannerDelegate?)
}

extension TostShowing {
    
    func showTost(header: String, message: String,toastType: ToastType, duration: ToastDuration? = .medium, toastGravity: BannerPosition? = .top, toastCornerRadius: Int? = 10, delegate:NotificationBannerDelegate? = nil){
        let toastView = ToastView()
        toastView.headLabel.text = header
        toastView.msgLabel.text = message
        toastView.applyStyle(toastType: toastType)
        
        let banner = FloatingNotificationBanner(customView: toastView)
        banner.bannerQueue.removeAll()
        
        var toastDuration = 2.0
        switch duration {
        case .short: toastDuration = 2.0;break
        case .medium: toastDuration = 3;break
        case .long: toastDuration = 4.0;break
        case .custom(let duration): toastDuration = duration
        case .none: break
        }
        
        banner.duration = toastDuration
        banner.delegate = delegate
        banner.transparency = 0.75
        banner.show(queuePosition: .front,
                    bannerPosition: toastGravity ?? .top,
                    cornerRadius: 10,
                    shadowBlurRadius: 15)
    }

}



extension UIColor {
    static let primary = UIColor(named: "Primary")!
    static let primaryDim = UIColor(named: "Primary-Dim")!
    
    static let secondary = UIColor(named: "Secondary")!
    static let secondaryDim = UIColor(named: "Secondary-Dim")!
    
    static let tertiary = UIColor(named: "Tertiary")!
    static let tertiaryDim = UIColor(named: "Tertiary-Dim")!
    
    static let tintPrimary = UIColor(named: "Tint-Primary")!
    static let tintPrimaryDim = UIColor(named: "Tint-Primary-Dim")!
    
    static let tintSecondary = UIColor(named: "Tint-Secondary")!
    static let tintSecondaryDim = UIColor(named: "Tint-Secondary-Dim")!
    
    static let tintTertiary = UIColor(named: "Tint-Tertiary")!
    static let tintTertiaryDim = UIColor(named: "Tint-Tertiary-Dim")!
    
    static let success = UIColor(named: "Success")!
    static let successDim = UIColor(named: "Success-Dim")!
    
    static let error = UIColor(named: "Error")!
    static let errorDim = UIColor(named: "Error-Dim")!
    
    static let warning = UIColor(named: "Warning")!
    static let warningDim = UIColor(named: "Warning-Dim")!
    
    static let information = UIColor(named: "Information")!
    static let informationDim = UIColor(named: "Information-Dim")!
    
    static let separator = UIColor(named: "Separator")!
    static let placeholder = UIColor(named: "Placeholder")!
    static let disabled = UIColor(named: "Disabled")!
    
    static let assetNeutral = UIColor(named: "asset-neutral")!
    static let assetLose = UIColor(named: "asset-lose")!
    static let assetGain = UIColor(named: "asset-gain")!
    
}

extension UIView {
    
    func  addTapGesture(action : @escaping ()->Void ){
        let tap = MyTapGestureRecognizer(target: self , action: #selector(self.handleTap(_:)))
        tap.action = action
        tap.numberOfTapsRequired = 1
        
        self.addGestureRecognizer(tap)
        self.isUserInteractionEnabled = true
        
    }
    @objc func handleTap(_ sender: MyTapGestureRecognizer) {
        sender.action!()
    }
}
class MyTapGestureRecognizer: UITapGestureRecognizer {
    var action : (()->Void)? = nil
}
